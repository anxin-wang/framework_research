describe('My module', function () {

  describe('spec', function () {
    it('unit test should run', function () {
      expect(true).toBe(true);
    });
  });

});