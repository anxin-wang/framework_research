# Built with Kraken

Build a site with Kraken? <a href="mailto:&#104;&#101;llo&#64;&#103;om&#97;ke&#116;h&#105;&#110;&#103;s.&#99;o&#109;">Let me know!</a>

</div></div><!-- /.grid-two-thirds /.row: Go full width -->

<div class="row text-center">
	<div class="grid-fourth">
		<p>
			<a href="http://www.pawsnewengland.com/">
				<img src="assets/img/logos/paws.png" height="119" width="212" alt="Screenshot of the PAWS New England website"><br>
				PAWS New England
			</a>
		</p>
	</div>
	<div class="grid-fourth">
		<p>
			<a href="http://www.shiftit.com.br/">
				<img src="assets/img/logos/shift-it.png" height="119" width="212" alt="Screenshot of Shiftit.com.br"><br>
				Shift it
			</a>
		</p>
	</div>
	<div class="grid-fourth">
		<p>
			<a href="http://www.benjaminobdyke.com/">
				<img src="assets/img/logos/benjamin-obdyke.png" height="119" width="212" alt="Screenshot of BenjaminObdyke.com"><br>
				Benjamin Obdyke
			</a>
		</p>
	</div>
	<div class="grid-fourth">
		<p>
			<a href="http://osasu.com/">
				<img src="assets/img/logos/osasu.png" height="119" width="212" alt="Screenshot of osasu.com"><br>
				Osasu
			</a>
		</p>
	</div>
</div>
<div class="row text-center">
	<div class="grid-fourth">
		<p>
			<a href="http://nicoleburley.com/">
				<img src="assets/img/logos/nicole-burley-coaching.png" height="119" width="212" alt="Screenshot of NicoleBurley.com"><br>
				Nicole Burley Coaching
			</a>
		</p>
	</div>
	<div class="grid-fourth">
		<p>
			<a href="http://poetreatapp.com/">
				<img src="assets/img/logos/poetreat.png" height="119" width="212" alt="Screenshot of Poetreat.com"><br>
				Poetreat
			</a>
		</p>
	</div>
	<div class="grid-fourth">
		<p>
			<a href="http://gomakethings.com/">
				<img src="assets/img/logos/gmt.png" height="119" width="212" alt="Screenshot of Go Make Things"><br>
				Go Make Things
			</a>
		</p>
	</div>
	<div class="grid-fourth">
		<p>
			<a href="http://barryzimmerman.co.uk/">
				<img src="assets/img/logos/barryz.png" height="119" width="212" alt="Screenshot of BarryZimmerman.co.uk"><br>
				Barry Zimmerman
			</a>
		</p>
	</div>
</div>
<div class="row text-center">
	<div class="grid-fourth">
		<p>
			<a href="http://exisweb.net/">
				<img src="assets/img/logos/exis.png" height="119" width="212" alt="Screenshot of ExisWeb.com"><br>
				Exis
			</a>
		</p>
	</div>
	<div class="grid-fourth">
		<p>
			<a href="http://tonyluong.com/">
				<img src="assets/img/logos/tony-luong.png" height="119" width="212" alt="Screenshot of TonyLuong.com"><br>
				Tony Luong Photography
			</a>
		</p>
	</div>
</div>