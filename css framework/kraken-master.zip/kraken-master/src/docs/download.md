# Download

There are three ways to use Kraken on your project:

* [Download Kraken](https://github.com/cferdinandi/kraken/archive/master.zip) directly from GitHub.
* Clone Kraken from GitHub: `git@github.com:cferdinandi/kraken.git`
* Install Kraken using your favorite package manager:
	* [NPM](https://www.npmjs.org/): `npm install cferdinandi/kraken`
	* [Bower](http://bower.io/): `bower install https://github.com/cferdinandi/kraken.git`
	* [Component](http://component.io/): `component install cferdinandi/kraken`